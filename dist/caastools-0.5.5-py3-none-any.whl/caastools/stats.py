from bisect import bisect_left
from collections import Counter
from scipy import stats
import io
import itertools
import logging
import numpy
import pandas


logging.getLogger('caastools.stats').addHandler(logging.NullHandler())


def __alpha_out__(out, cmx, dmx, alpha, lower, upper, alpha_levels, probabilities):

    sep = "===================================================\n\n"
    try:
        out.write("Coincidence matrix:\n")
    except io.UnsupportedOperation as uo_err:
        logging.error(str(uo_err))
    except AttributeError:
        try:
            with open(out, 'w') as out:
                out.write("Coincidence matrix:\n")
                out.write(cmx.to_string() + "\n")
                out.write(sep)
                out.write("Difference Matrix:\n")
                out.write(dmx.to_string() + "\n")
                out.write(sep)
                if lower != numpy.NaN and upper != numpy.NaN:
                    out.write("alpha, 95% CI:\n")
                    out.write("{0:.3f}, {{{1:.3f}, {2:.3f}}}\n".format(alpha, lower, upper))
                    out.write(sep)
                    out.write("Probability of failing to atttain selected values of alpha:\n")
                    for i, level in enumerate(alpha_levels):
                        out.write("{0:<.2f}: {1:<.3f}\n".format(level, probabilities[i]))
        except OSError as os_error:
            logging.error("Unable to create output because 'out' was an invalid file handle")


def cohens_kappa(rows, columns, weight=None):
    """
    Computes cohen's kappa for the specified series
    :param rows: The series to comprise the rows of the crosstabulation. Accepts an iterable, Series, or numpy.array
    :param columns: The series to comprise the columns of the crosstabulation. Accepts an iterable, Series, or numpy.array
    :param weight the weighting scheme to apply (None, 'linear', 'quadratic') Default None
    :return tuple[float, float]: Cohen's kappa, maximum attainable kappa
    """
    if weight not in (None, 'linear', 'quadratic'):
        raise ValueError("Invalid weight specification")

    weight_funcs = {None: lambda x, y: 0 if x == y else 1,
                    'linear': lambda x, y: abs(x - y),
                    'quadratic': lambda x, y: (x - y) ** 2}

    diff_func = weight_funcs.get(weight)
    if diff_func is None:
        raise ValueError("Invalid weight specification")

    all_values = sorted(set(filter(lambda x: pandas.notna(x), itertools.chain(rows, columns))))
    if len(all_values) == 0:
        logging.warning("Unable to compute cohen's kappa because no non-missing values were found")
        return numpy.NaN, numpy.NaN

    index = pandas.Categorical(rows, categories=all_values)
    cols = pandas.Categorical(columns, categories=all_values)

    ct = pandas.crosstab(index, cols, normalize=True, dropna=False)

    # Get the marginal totals to compute expected agreement matrix later
    col_totals = ct.sum(axis=0, skipna=True)
    row_totals = ct.sum(axis=1, skipna=True)

    # Compute the weighting matrix
    row_cats = index.categories
    col_cats = cols.categories
    row_idx = range(len(row_cats))
    col_idx = range(len(col_cats))
    wm_arry = numpy.array([[diff_func(r, c) for c in col_idx] for r in row_idx])
    wm = pandas.DataFrame(data=wm_arry, index=ct.index, columns=ct.columns)

    # Compute the weighted matrix of observations
    wobs = ct * wm

    # Compute weighted expectancy matrix
    exp_arry = numpy.array([[rt * ct for ct in col_totals] for rt in row_totals])
    exp = pandas.DataFrame(exp_arry, index=row_totals.index, columns=col_totals.index)
    wexp = exp * wm

    # Compute kappa via the weighted matrices
    kappa = 1 - (wobs.sum().sum() / wexp.sum().sum())

    # compute the maximum attainable kappa
    pe = 1 - wexp.sum().sum()
    pmax = sum([min(a, b) for a, b in zip(row_totals, col_totals)])
    kmax = (pmax - pe) / (1 - pe)

    return kappa, kmax


def pabak(rater1, rater2):
    """
    stats.pabak(rows, colums) -> tuple[float, float, float]
    Computes the prevalance-adjusted, bias-adjusted kappa as described in:
    Byrt, T., Bishop, J., & Carlin, J. B. (1993). Prevalence, Bias, and Kappa.
    Journal of Clinical Epidemiology, 46(5), 423-429.
    :param rater1: The data from the first observer
    :param rater2: The data from the second observer
    :return: the PABAK statistic, prevalence index, and bias index
    """
    raise NotImplementedError()


def fleiss(frame: pandas.DataFrame, subject_column, rater_column, category_column):
    """
    stats.fleiss(frame: pandas.DataFrame) -> float
    Computes the fleiss multirater kappa from the provided count data
    :param frame: The DataFrame object containing all the raw observations
    :param subject_column: the name of the column that designates the subject being rated
    :param rater_column: the name of the column that specifies the rater
    :param category_column: the name of the column that specifies the category assigned to subject by rater
    :return: float
    """

    # First thing for a fleiss coefficient is to extract the necessary count data
    counts = frame[[subject_column,
                    rater_column,
                    category_column]].pivot_table(values=rater_column, index=subject_column, columns=category_column,
                                                  aggfunc=numpy.count_nonzero, fill_value=0)

    # Get number of subjects and categories
    N, k = counts.shape
    obs_count = counts.sum().sum()

    # number of raters
    n = obs_count // N

    # pj = proportion of agreement for a given category
    pj = counts.sum() / obs_count

    # pi = proportion of agreement for a given subject
    pi = (1 / (n * (n - 1))) * ((counts ** 2).sum(axis=1) - n)

    # pobs = proportion of observed agreement
    pobs = pi.sum() / N

    # pe = proportion of agreement expected by chance
    pe = (pj ** 2).sum()

    k = (pobs - pe) / (1 - pe)

    return k


def icc(frame: pandas.DataFrame, icc_type=2):
    """
    Compute Intraclass Correllation Coefficient
    Based on Bakeman, R., & Quera, V. (2011). Sequential Analysis and Observational
    Methods for the Behavioral Sciences.
    Formulas drawn from: McGraw, K. O. & Wong, S.P. (1996). Forming inferences about some intraclass
    correlation coefficients. Psychological Methods, 1(1), 30-46.

    :param frame: The pandas.DataFrame from which to compute the ICC
    :param icc_type: The type of ICC to run (only 2 and 3 currently supported). Default 2
    :return: tuple[float, float, float] The intraclass correlation coefficient, F and associated p-value
    :raises ValueError: If frame has fewer than 2 rows or columns
    """
    n, k = frame.shape

    if n < 2:
        raise ValueError("Unable to compute an ICC because fewer than 2 rows with non-missing data were found")
    if k < 2:
        raise ValueError("Unable to compute an ICC because fewer than 2 raters were found")

    icc_types = {1: lambda ms_sub, ms_err, ms_within, ms_r, df_r, k, n:
                 (ms_sub - ms_within) / (ms_sub + df_r * ms_within),
                 2: lambda ms_sub, ms_err, ms_within, ms_r, df_r, k, n:
                 (ms_sub - ms_err) / (ms_sub + df_r * ms_err + k * (ms_r - ms_err) / n),
                 3: lambda ms_sub, ms_err, ms_within, ms_r, df_r, k, n:
                 (ms_sub - ms_err) / (ms_sub + df_r * ms_err)}

    formula = icc_types.get(icc_type)
    if formula is None:
        raise ValueError("Invalid specification for icc_type. Expected (1, 2, 3)")

    # Degrees of Freedom
    df_raters = k - 1  # dfc
    df_subjects = n - 1  # dfr
    df_error = df_subjects * df_raters  # dfe
    df_within_rows = n * (k - 1)

    # Sum of squares Total
    grand_mean = frame.mean().mean()
    ss_total = ((frame - grand_mean) ** 2).sum().sum()

    # Sum of squares between raters (columns)
    ss_raters = n * ((frame.mean(0) - grand_mean) ** 2).sum()
    ms_raters = ss_raters / df_raters

    # Sum of Squares for the error term
    ss_within_cols = ss_total - ss_raters
    ss_rows = k * ((frame.mean(1) - grand_mean) ** 2).sum().sum()
    ss_error = ss_within_cols - ss_rows
    ms_error = ss_error / df_error

    # Sum of Squares between subjects (rows)
    ss_subjects = ss_within_cols - ss_error
    ms_subjects = ss_subjects / df_subjects

    # Sum of squares within subjects (rows)
    ss_within_subjects = ss_raters + ss_error
    ms_within_subjects = ss_within_subjects / df_within_rows

    coeff = formula(ms_subjects, ms_error, ms_within_subjects, ms_raters, df_raters, k, n)

    f = ms_subjects / ms_error

    return coeff, f, stats.f.sf(f, df_subjects, df_error)


def kalpha(data, metric='nominal', boot=None, out=None):
    """
    stats.k_alpha(data, metric='nominal') -> float
    Computes Krippendorf's alpha-reliability for the provided DataFrame
    Data should be structured S.T. raters are the index,
    subjects are the columns, and observations are the cell values
    :param data: pandas.DataFrame holding the observational data
    :param metric: string specifying the type of data/metric. Default 'nominal'
    Acceptable values are 'nominal', 'ordinal', 'interval', 'ratio'
    :param boot: number of samples to take for bootstrapping the CI, or None if no bootstrapping desired
    :param out: file-like object or path to file to which to write output. Default None. Output includes
    coincidence matrix, delta matrix, and if bootstrapping, 95% CI and probabilities to attain various levels of alpha.
    :return tuple[float, float, float]: alpha and the lower/upper bounds of the 95% CI
    """

    metrics = {'nominal': lambda x, y: int(x != y),
               'ordinal': lambda row, lower, upper:
               (sum(row.loc[lower: upper]) -
                ((row.loc[lower] + row.loc[upper]) / 2)) ** 2,
               'interval': lambda x, y: (x - y) ** 2,
               'ratio': lambda x, y: ((x - y) / (x + y)) ** 2}

    er = []

    diff_func = metrics.get(metric)
    if diff_func is None:
        raise ValueError(
            "Parameter metric expected one of ('nominal', 'ordinal', 'interval', 'ratio'), got {0}".format(metric))

    # comptue the coincidence matrix
    idx = sorted(set(filter(lambda x: pandas.notna(x), data.values.ravel())))
    cmx = pandas.DataFrame(0, index=idx, columns=idx)
    expect = cmx.copy()

    for col in data.columns:
        mu = len(data[col].dropna())
        pairings = itertools.permutations(data[col].dropna(), 2)
        counts = Counter(tuple(itm) for itm in pairings)
        for key, value in counts.items():
            cmx.loc[key] += value / (mu - 1)

    marginals = cmx.sum()
    n = marginals.sum()

    # compute the matrix of expected coincidences
    for row in idx:
        for col in idx:
            if row == col:
                expect.loc[row, col] = marginals[row] * (marginals[col] - 1) / (n - 1)
            else:
                expect.loc[row, col] = marginals[row] * marginals[col] / (n - 1)

    # Compute the difference matrix
    dmx = pandas.DataFrame(0, index=idx, columns=idx)
    for r, c in itertools.product(idx, idx):
        lower = c if c < r else r
        upper = r if c < r else c
        dmx.loc[r, c] = diff_func(lower, upper) if metric != 'ordinal' else diff_func(marginals, lower, upper)

    # compute the matrix of observed disagreement
    dobs = cmx * dmx

    # compute the matrix of expected disagreement
    dexp = dmx * expect

    # compute alpha
    do = dobs.sum().sum()
    de = dexp.sum().sum()
    alpha = 1 - (do / de)

    # Perform the bootstrapping via the Hayes algorithm
    if boot is None:
        lower, upper = (numpy.NaN, numpy.NaN)
    else:
        n_boot = (boot // 1000) * 1000
        if n_boot < 1000:
            logging.warning("Minimum number of bootstraps is 1000. Setting boot to 1000 samples")
            n_boot = 1000

        boot_samples = []
        # First, compute the E(r) term for each pair of values
        bs_data = data.dropna(axis=1, thresh=2)
        for col in bs_data:
            column_data = bs_data[col].dropna()
            mu = len(column_data)
            for i, v1 in enumerate(column_data[:-1]):
                for v2 in column_data[i + 1:]:
                    diff = diff_func(v1, v2) if metric != 'ordinal' else diff_func(marginals, v1, v2)
                    e = 2 * (diff / de)
                    delta = e / (mu - 1)
                    er.append(delta)

        # Then perform the sampling and compute the estimated bootstrapped alpha for each sample
        for i in range(n_boot):
            boot_alpha = 1
            last_choice = -1
            for col in bs_data:
                mu = len(bs_data[col].dropna())
                for j in range((mu * mu - 1) // 2):
                    choice = numpy.random.randint(0, len(er))
                    while j == 2 and choice == last_choice:
                        choice = numpy.random.randint(0, len(er))
                    last_choice = choice
                    delta = er[choice]
                    boot_alpha -= delta

            boot_samples.append(boot_alpha)

        # Determine the probability of failing to attain specific values of alpha
        alpha_levels = [0.5, 0.6, 0.67, 0.7, 0.8, 0.9]
        boot_samples.sort()
        probabilities = [bisect_left(boot_samples, l) / n_boot for l in alpha_levels]
        lower, upper = numpy.quantile(boot_samples, q=(.025, .975))

    if out is not None:
        __alpha_out__(out, cmx, dmx, alpha, lower, upper, alpha_levels, probabilities)

    return alpha, lower, upper
